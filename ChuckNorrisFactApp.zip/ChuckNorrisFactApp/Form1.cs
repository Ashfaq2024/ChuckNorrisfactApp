﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Purpose: This app fetches and displays a random Chuck Norris fact from an external API.
 * Author: Ashfaq Adil
 * Date: 03/02/2025
 */

namespace ChuckNorrisFactApp
{
    public partial class Form1 : Form
    {
        private const string ApiUrl = "https://api.chucknorris.io/jokes/random";

        public Form1()
        {
            InitializeComponent();
        }

        // Event handler for the "Get Fact" button
        private async void BtnGetFact_Click(object sender, EventArgs e)
        {
            try
            {
                // Fetch a Chuck Norris fact from the API
                string fact = await GetChuckNorrisFactAsync();
                lblFact.Text = fact; // Display the fact in the label
            }
            catch (Exception ex)
            {
                lblFact.Text = "Failed to fetch fact. Please try again.";
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to fetch a Chuck Norris fact from the API
        private async Task<string> GetChuckNorrisFactAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                // Send a GET request to the API
                HttpResponseMessage response = await client.GetAsync(ApiUrl);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Read the response content as a string
                string jsonResponse = await response.Content.ReadAsStringAsync();

                // Parse the JSON response to extract the fact
                var factObject = JsonConvert.DeserializeObject<ChuckNorrisFact>(jsonResponse);

                return factObject.Value; // Return the fact
            }
        }

        // Class to represent the Chuck Norris fact in the JSON response
        private class ChuckNorrisFact
        {
            public string Value { get; set; }
        }
    }
}