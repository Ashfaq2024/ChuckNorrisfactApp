﻿namespace ChuckNorrisFactApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnGetFact;
        private System.Windows.Forms.Label lblFact;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnGetFact = new System.Windows.Forms.Button();
            this.lblFact = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGetFact
            // 
            this.btnGetFact.Location = new System.Drawing.Point(20, 20);
            this.btnGetFact.Name = "btnGetFact";
            this.btnGetFact.Size = new System.Drawing.Size(100, 30);
            this.btnGetFact.TabIndex = 0;
            this.btnGetFact.Text = "Get Fact";
            this.btnGetFact.UseVisualStyleBackColor = true;
            this.btnGetFact.Click += new System.EventHandler(this.BtnGetFact_Click);
            // 
            // lblFact
            // 
            this.lblFact.Location = new System.Drawing.Point(20, 70);
            this.lblFact.Name = "lblFact";
            this.lblFact.Size = new System.Drawing.Size(300, 20);
            this.lblFact.TabIndex = 1;
            this.lblFact.Text = "Click the button to get a fact!";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(400, 150);
            this.Controls.Add(this.lblFact);
            this.Controls.Add(this.btnGetFact);
            this.Name = "Form1";
            this.ResumeLayout(false);
        }
    }
}